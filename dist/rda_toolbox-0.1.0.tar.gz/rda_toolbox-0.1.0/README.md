# Robotic-assisted Discovery of Antiinfectives


### Readers
- Cytation C10

<!-- https://testdriven.io/blog/python-project-workflow/ -->
